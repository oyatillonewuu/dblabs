class DbException(Exception):
    pass
